package sh;

import java.util.*;

public class Block {
	public String hash;
	public String previousHash;
	private String data;
	private long timeStamp;
	private int nonce;

	
	public Block(String data, String previousHash) {
		this.data = data;
		this.previousHash = previousHash;
		this.hash = calculateHash();
	}
	
	public void printBlock() {
		System.out.println("Data: " + this.data);
		System.out.println("Previous Hash: " + this.previousHash);
		System.out.println("Hash: " + this.hash);
		System.out.println("Time: " + this.timeStamp);
		System.out.println("Nonce: " + this.nonce);
		System.out.println();
	}


	public String calculateHash() {
		ApplyHash a = new ApplyHash();
		String aha = this.data + this.previousHash + this.timeStamp + this.nonce;
		String resultHash = a.applyHashingAlgorithm(aha);
		return resultHash;
	}
}


