package sh;

import java.util.ArrayList;
public class BChain {
	public static ArrayList<Block> block = new ArrayList<Block>();
	public static void main(String[] args) {
		Block b = new Block("First block", "0");
		block.add(b);
		b.printBlock();
		Block c = new Block("Second block", block.get(block.size() - 1).hash);
		block.add(c);
		c.printBlock();
		Block d = new Block("Third block", block.get(block.size() - 1).hash);
		block.add(d);
		d.printBlock();
		
		Block e = new Block("Fourth Block", block.get(block.size() - 1).hash);
		block.add(e);
		e.printBlock();
		
	     
		
		Boolean check = checkValidity();
		System.out.println("Validate: " + check);
		
		
	}
	
	public static Boolean checkValidity()
	{
	    Block currentBlock;
	    Block previousBlock;

	    for (int i = 1;i < block.size();i++) {

	        currentBlock = block.get(i);
	        previousBlock = block.get(i - 1);
	  
	        
	        if (!currentBlock.hash.equals(currentBlock.calculateHash())) {
	            System.out.println("Hashes are not equal");
	            return false;
	        }

	        if (!previousBlock.hash.equals(currentBlock.previousHash)) {
	            System.out.println("Previous Hashes are not equal");
	            return false;
	        }
	    }
	  	    return true;
	}
}
